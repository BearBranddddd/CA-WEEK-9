﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Add_User : Form
    {
        List<string> username;
        List<string> password;
        Form2 form2;
        public Add_User(Form form,List<string> username, List<string> password)
        {
            InitializeComponent();
            this.form2 = (Form2)form;
            this.username = username;
            this.password = password;
        }

        private void b_adduser_Click(object sender, EventArgs e)
        {
            if (tb_addpw.Text == tb.Text)
            {
                bool tes = false;
                for (int i = 0; i < username.Count; i++)
                {
                    if (tb_adduser.Text == username[i])
                    {
                        tes = true;
                        break;
                    }
                }
                if (tes == true)
                {
                    MessageBox.Show("User already exist!");
                    tb_addpw.Text = "";
                    tb_adduser.Text = "";
                    tb.Text = "";
                }
                else
                {
                    MessageBox.Show("User Added");
                    username.Add(tb_adduser.Text);
                    password.Add(tb.Text);
                    tb_addpw.Text = "";
                    tb_adduser.Text = "";
                    tb.Text = "";
                    tes = false;
                }
            }
            else
            {
                MessageBox.Show("Passwords not match");
            }
            
        }
    }
}

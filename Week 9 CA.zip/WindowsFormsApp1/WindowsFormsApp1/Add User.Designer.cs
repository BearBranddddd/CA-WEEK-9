﻿namespace WindowsFormsApp1
{
    partial class Add_User
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb = new System.Windows.Forms.TextBox();
            this.tb_addpw = new System.Windows.Forms.TextBox();
            this.tb_adduser = new System.Windows.Forms.TextBox();
            this.b_adduser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(61, 104);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(65, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Password";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(65, 209);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Confirm Password";
            // 
            // tb
            // 
            this.tb.Location = new System.Drawing.Point(257, 203);
            this.tb.Name = "tb";
            this.tb.Size = new System.Drawing.Size(191, 31);
            this.tb.TabIndex = 3;
            this.tb.UseSystemPasswordChar = true;
            // 
            // tb_addpw
            // 
            this.tb_addpw.Location = new System.Drawing.Point(257, 156);
            this.tb_addpw.Name = "tb_addpw";
            this.tb_addpw.Size = new System.Drawing.Size(191, 31);
            this.tb_addpw.TabIndex = 4;
            this.tb_addpw.UseSystemPasswordChar = true;
            // 
            // tb_adduser
            // 
            this.tb_adduser.Location = new System.Drawing.Point(257, 104);
            this.tb_adduser.Name = "tb_adduser";
            this.tb_adduser.Size = new System.Drawing.Size(191, 31);
            this.tb_adduser.TabIndex = 5;
            // 
            // b_adduser
            // 
            this.b_adduser.Location = new System.Drawing.Point(257, 272);
            this.b_adduser.Name = "b_adduser";
            this.b_adduser.Size = new System.Drawing.Size(130, 38);
            this.b_adduser.TabIndex = 6;
            this.b_adduser.Text = "Add User";
            this.b_adduser.UseVisualStyleBackColor = true;
            this.b_adduser.Click += new System.EventHandler(this.b_adduser_Click);
            // 
            // Add_User
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 566);
            this.Controls.Add(this.b_adduser);
            this.Controls.Add(this.tb_adduser);
            this.Controls.Add(this.tb_addpw);
            this.Controls.Add(this.tb);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Add_User";
            this.Text = "Add_User";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb;
        private System.Windows.Forms.TextBox tb_addpw;
        private System.Windows.Forms.TextBox tb_adduser;
        private System.Windows.Forms.Button b_adduser;
    }
}
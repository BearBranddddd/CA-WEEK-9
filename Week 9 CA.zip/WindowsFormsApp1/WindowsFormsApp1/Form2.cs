﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form2 : Form
    {
        List<string> username;
        List<string> password;
        Form1 form1;
        Add_User form3;
        string usernamee;
        public Form2(Form form, List <string>username, List<string> password, string usernamee)
        {
            InitializeComponent();
            this.form1 = (Form1)form;
            this.username = username;
            this.password = password;
            this.usernamee = usernamee;
            timer1.Start();

        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            form3 = new Add_User(this, username, password);
            form3.MdiParent = this;
            form3.Show();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            stripname.Text = usernamee;
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            form1.closeform2();
            form1.Show();
        }

        public void closeform1()
        {
            form1.Hide();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            date.Text = DateTime.Now.ToString("ddd, dd - MM - yyy HH:mm:ss");
        }
    }
}

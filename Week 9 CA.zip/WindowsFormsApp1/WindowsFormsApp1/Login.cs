﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        Form2 form2;
        List<string> username = new List<string>();
        List<string> password = new List<string>();
        string usernamee = "";
        private void Form1_Load(object sender, EventArgs e)
        {
            username.Add("admin");
            password.Add("admin");
        }
        public void closeform2()
        {
            form2.Hide();
        }
        bool cek = false;
        private void b_login_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < username.Count; i++)
            {
                if (username[i] == tb_loginuser.Text)
                {
                    if (password[i] == tb_loginpw.Text)
                    {
                        usernamee = username[i];
                        cek = true;
                        break;
                    }
                }
            }

            if (cek == true)
            {
                cek = false;
                form2 = new Form2(this, username,password, usernamee);
                form2.Show();
                form2.closeform1();
                tb_loginpw.Text = "";
                tb_loginuser.Text = "";
            }
            else
            {
                MessageBox.Show("Username or Password is incorect");
                tb_loginpw.Text = "";
                tb_loginuser.Text = "";
            }
        }
    }
}
